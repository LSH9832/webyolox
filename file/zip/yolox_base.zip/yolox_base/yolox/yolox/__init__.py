from .utils import configure_module

configure_module()

__version__ = "0.1.0"
