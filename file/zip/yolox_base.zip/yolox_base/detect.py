"""
author: LSH9832
"""
from yolox import Detector, draw_bb
import cv2

if __name__ == '__main__':
    detector = Detector(
        model_path="./yolox_s.pth",
        model_size="s",
        class_path="./coco_classes.txt",
        conf=0.25,
        nms=0.4,
        input_size=640,         # 一定要32的整数倍
        fp16=False              # 嵌入式上用True会快很多
    )

    """
    or create detector as follows
    """
    # from yolox import create_detector_from_settings
    # detector = create_detector_from_settings("./detect_settings.yaml")

    detector.loadModel()

    cap = cv2.VideoCapture("./test.ts")
    while cap.isOpened():
        success, image = cap.read()
        if success:
            result = detector.predict(image)

            draw_bb(image, result, detector.get_all_classes())
            cv2.imshow("image", image)
            if cv2.waitKey(1) == 27:    # esc
                cv2.destroyAllWindows()
                break
